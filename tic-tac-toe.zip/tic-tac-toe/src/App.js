import React, { useState } from "react";
import Board from "./components/Board";
import "./App.css";

function App() {
  const [isTwoPlayer, setIsTwoPlayer] = useState(true);
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState(null);

  const handleModeChange = (mode) => {
    setIsTwoPlayer(mode === "two");
    resetGame();
  };

  const resetGame = () => {
    setGameOver(false);
    setWinner(null);
  };

  return (
    <div className="App">
      <h1>Tic-Tac-Toe</h1>
      <div className="mode-buttons">
        <button onClick={() => handleModeChange("two")}>Two Player</button>
        <button onClick={() => handleModeChange("computer")}>Play vs Computer</button>
      </div>
      <Board
        isTwoPlayer={isTwoPlayer}
        gameOver={gameOver}
        setGameOver={setGameOver}
        winner={winner}
        setWinner={setWinner}
      />
      {winner && <h2>Winner: {winner}</h2>}
    </div>
  );
}

export default App;
