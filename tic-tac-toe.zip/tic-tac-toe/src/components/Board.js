import React, { useState, useEffect } from "react";
import Square from "./Square";

const Board = ({ isTwoPlayer, gameOver, setGameOver, winner, setWinner }) => {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);

  const checkWinner = (board) => {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (let line of lines) {
      const [a, b, c] = line;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        return board[a];
      }
    }
    return null;
  };

  const handleClick = (index) => {
    if (board[index] || gameOver) return;

    const newBoard = [...board];
    newBoard[index] = xIsNext ? "X" : "O";
    setBoard(newBoard);
    const win = checkWinner(newBoard);
    if (win) {
      setWinner(win);
      setGameOver(true);
    } else if (!newBoard.includes(null)) {
      setWinner("Draw");
      setGameOver(true);
    } else {
      setXIsNext(!xIsNext);
    }
  };

  // Simple computer move (random)
  useEffect(() => {
    if (!isTwoPlayer && !xIsNext && !gameOver) {
      let emptyIndices = board.map((val, idx) => (val === null ? idx : null)).filter((v) => v !== null);
      if (emptyIndices.length > 0) {
        const randomMove = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
        handleClick(randomMove);
      }
    }
  }, [board, xIsNext, isTwoPlayer, gameOver]);

  const resetBoard = () => {
    setBoard(Array(9).fill(null));
    setXIsNext(true);
    setGameOver(false);
    setWinner(null);
  };

  return (
    <div>
      <div className="board">
        {board.map((value, index) => (
          <Square key={index} value={value} onClick={() => handleClick(index)} />
        ))}
      </div>
      <button className="reset-btn" onClick={resetBoard}>
        Reset Game
      </button>
    </div>
  );
};

export default Board;
