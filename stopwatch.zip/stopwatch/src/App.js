import React from "react";
import Stopwatch from "./Stopwatch";

function App() {
  return (
    <div>
      <Stopwatch />
    </div>
  );
}

export default App;
